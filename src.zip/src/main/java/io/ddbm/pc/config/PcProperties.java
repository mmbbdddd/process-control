package io.ddbm.pc.config;

import lombok.Data;


@Data
public class PcProperties {
    String flowPath;
}
