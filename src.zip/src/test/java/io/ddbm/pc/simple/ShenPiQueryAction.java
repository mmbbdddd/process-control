package io.ddbm.pc.simple;

import io.ddbm.pc.Action;
import io.ddbm.pc.FlowContext;
import io.ddbm.pc.exception.InterruptException;
import io.ddbm.pc.exception.PauseException;

public class ShenPiQueryAction implements Action {
    @Override
    public void execute(FlowContext ctx) throws PauseException, InterruptException {

    }
}
