package io.ddbm.pc.ex;

public class A2 extends A{
    public A2(){
        this.name = "A2";
    }
    public void say(){
        System.out.println("A2@"+name);
    }
}
