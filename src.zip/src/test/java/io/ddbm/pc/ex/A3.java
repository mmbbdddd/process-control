package io.ddbm.pc.ex;

public class A3 extends A{
    public A3(){
        this.name = "A3";
    }
    public void say(){
        System.out.println("A3@"+name);
    }
}
