package io.ddbm.pc.ex;

public class A1  extends A{
    public A1(){
        this.name = "A1";
    }
}
